from flask import Flask, render_template, request

app = Flask(__name__)

nama_lengkap = "Muhammad Alfan"
welcome_message = f"Selamat datang di Sistem Pendataan Kendaraan by {nama_lengkap}"

@app.route('/')
def home():
    return render_template('index.html', welcome_message=welcome_message)

@app.route('/pendataan', methods=['GET', 'POST'])
def pendataan():
    if request.method == 'POST':
        jenis_kendaraan = request.form['jenis_kendaraan']
        merek = request.form['merek']
        nomor_plat = request.form['nomor_plat']

        return render_template('detail.html', jenis_kendaraan=jenis_kendaraan, merek=merek, nomor_plat=nomor_plat)

    return render_template('detail.html')

if __name__ == '__main__':
    app.run(debug=True)
